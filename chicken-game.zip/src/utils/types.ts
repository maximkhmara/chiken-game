export interface LevelConfig {
  id: number;
  enemyCount: number;
  timeLimit: number;
}